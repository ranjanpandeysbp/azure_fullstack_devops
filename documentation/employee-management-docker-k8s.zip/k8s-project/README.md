# Employee Management — Docker + Kubernetes on Azure (AKS)
## React + Spring Boot + Azure SQL → Docker → ACR → AKS

---

## 🚀 Quick Start — Local with Docker Compose

```bash
# Start entire stack (React + Spring Boot + SQL Server)
docker compose up --build

# App:    http://localhost:3000  (or :80)
# API:    http://localhost:8080/api/health
# (SQL Server runs in container — no Azure account needed!)

# Stop and remove volumes
docker compose down -v
```

---

## ☸️ Deploy to AKS

### Step 1 — Deploy Infrastructure
```bash
bash infrastructure/cli-scripts/deploy-aks.sh dev
# Creates: AKS, ACR, Azure SQL, Key Vault, App Insights, Managed Identity
```

### Step 2 — Run CI/CD Pipelines (Azure DevOps)
```
azure-pipelines-backend-k8s.yml   → builds JAR → Docker image → push to ACR → deploy to AKS
azure-pipelines-frontend-k8s.yml  → build React → Docker image → push to ACR → deploy to AKS
```

### Step 3 — Or Deploy Manually with kubectl
```bash
# Get AKS credentials
az aks get-credentials --resource-group rg-emp-aks-dev --name aks-emp-dev

# Apply manifests (dev overlay)
kubectl apply -k k8s/overlays/dev

# Watch rollout
kubectl rollout status deployment/backend -n employee-app
kubectl rollout status deployment/frontend -n employee-app

# Check pods
kubectl get pods -n employee-app
kubectl get svc  -n employee-app
kubectl get hpa  -n employee-app
```

### Deploy with Helm
```bash
helm upgrade --install emp ./helm/employee-app \
  --namespace employee-app \
  --create-namespace \
  --set global.registry=myacr.azurecr.io \
  --set global.imageTag=latest \
  --set secrets.azureSqlUrl="jdbc:sqlserver://..." \
  --set secrets.azureSqlPassword="YourPassword"
```

---

## 🧱 Project Structure
```
├── backend/                        # Spring Boot API
│   ├── Dockerfile                  # Multi-stage: Maven build → JRE runtime
│   ├── src/main/resources/
│   │   ├── application-local.yml   # H2 in-memory (local dev, no Docker)
│   │   ├── application-docker.yml  # SQL Server in docker-compose
│   │   └── application-azure.yml   # Azure SQL (AKS / App Service)
│   └── pom.xml
│
├── frontend/                       # React 18 + MUI
│   ├── Dockerfile                  # Multi-stage: Node build → Nginx serve
│   └── nginx.conf                  # SPA routing + security headers
│
├── docker-compose.yml              # Full local stack (React + Spring + SQL Server)
│
├── k8s/
│   ├── base/                       # Base Kubernetes manifests
│   │   ├── namespace.yaml
│   │   ├── backend-deployment.yaml # Deployment + Service + probes + resources
│   │   ├── frontend-deployment.yaml
│   │   ├── ingress.yaml            # NGINX Ingress + TLS (cert-manager)
│   │   ├── hpa.yaml                # Horizontal Pod Autoscaler
│   │   ├── pdb.yaml                # Pod Disruption Budget (HA)
│   │   ├── network-policy.yaml     # Pod-to-pod traffic rules
│   │   ├── configmap.yaml
│   │   ├── secret.yaml             # Template — real values injected by pipeline
│   │   └── serviceaccount.yaml     # Azure Workload Identity
│   └── overlays/
│       ├── dev/kustomization.yaml  # Dev: 1 replica, dev image tags
│       └── prod/kustomization.yaml # Prod: 3 replicas, prod image tags
│
├── helm/employee-app/              # Helm chart (alternative to Kustomize)
│   ├── Chart.yaml
│   ├── values.yaml                 # Default values
│   ├── values-prod.yaml            # Production overrides
│   └── templates/                  # backend, frontend, ingress, secret, sa
│
├── infrastructure/
│   ├── bicep/aks-main.bicep        # Full IaC: AKS + ACR + SQL + KV + RBAC
│   └── cli-scripts/deploy-aks.sh   # Complete CLI deployment script
│
└── pipelines/
    ├── azure-pipelines-frontend-k8s.yml  # React: Test → Docker → ACR → AKS
    └── azure-pipelines-backend-k8s.yml   # Spring Boot: Maven → Docker → ACR → AKS
```

---

## 🔐 Secrets Architecture
```
Azure Key Vault
  ↓  (RBAC: Key Vault Secrets User)
Managed Identity (User-Assigned)
  ↓  (Workload Identity Federation via OIDC)
Kubernetes ServiceAccount (backend-sa)
  ↓  (bound to backend pods)
Spring Boot reads env vars → AZURE_SQL_URL, AZURE_SQL_PASSWORD
```

## 🌐 Environments
| Profile | Database | Activated By |
|---------|----------|--------------|
| local   | H2 in-memory | `mvnw spring-boot:run -Dspring-boot.run.profiles=local` |
| docker  | SQL Server container | `docker compose up` |
| azure   | Azure SQL Database | `SPRING_PROFILES_ACTIVE=azure` in AKS/App Service |
