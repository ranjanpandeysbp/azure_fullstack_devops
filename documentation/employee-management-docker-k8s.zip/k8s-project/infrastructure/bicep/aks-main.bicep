// ============================================================
// aks-main.bicep — AKS + ACR + Azure SQL + Key Vault + App Insights
// Deploy: az deployment group create -g RG -f aks-main.bicep -p @aks-params.json
// ============================================================
targetScope = 'resourceGroup'

@description('Environment: dev, staging, prod')
@allowed(['dev', 'staging', 'prod'])
param environment string = 'dev'

param location string = resourceGroup().location

@secure()
param sqlAdminPassword string

param sqlAdminLogin string = 'sqladmin'

// ── Naming ───────────────────────────────────────────────────
var prefix = 'emp'
var suffix = take(uniqueString(resourceGroup().id), 6)

var aksName    = 'aks-${prefix}-${environment}'
var acrName    = '${prefix}acr${environment}${suffix}'
var sqlServer  = '${prefix}-sql-${environment}-${suffix}'
var sqlDb      = '${prefix}-db-${environment}'
var kvName     = 'kv-${prefix}-${environment}-${suffix}'
var appiName   = 'appi-${prefix}-${environment}'
var lawName    = 'law-${prefix}-${environment}'
var miName     = 'mi-${prefix}-${environment}'

// ── Log Analytics + App Insights ─────────────────────────────
resource law 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: lawName
  location: location
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

resource appi 'Microsoft.Insights/components@2020-02-02' = {
  name: appiName
  location: location
  kind: 'web'
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: law.id
  }
}

// ── Azure Container Registry (ACR) ───────────────────────────
resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: acrName
  location: location
  sku: { name: environment == 'prod' ? 'Premium' : 'Basic' }
  properties: {
    adminUserEnabled: false   // Use managed identity, not admin creds
    publicNetworkAccess: 'Enabled'
  }
}

// ── User-Assigned Managed Identity (for workload identity) ───
resource managedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: miName
  location: location
}

// ── AKS Cluster ──────────────────────────────────────────────
resource aks 'Microsoft.ContainerService/managedClusters@2024-01-01' = {
  name: aksName
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    dnsPrefix: '${prefix}-${environment}'
    kubernetesVersion: '1.29'
    enableRBAC: true

    // Workload Identity + OIDC (for Key Vault access without secrets)
    oidcIssuerProfile: { enabled: true }
    securityProfile: { workloadIdentity: { enabled: true } }

    agentPoolProfiles: [
      {
        name: 'system'
        count: environment == 'prod' ? 3 : 1
        vmSize: environment == 'prod' ? 'Standard_D4s_v3' : 'Standard_D2s_v3'
        osType: 'Linux'
        mode: 'System'
        enableAutoScaling: true
        minCount: environment == 'prod' ? 2 : 1
        maxCount: environment == 'prod' ? 10 : 3
        osDiskSizeGB: 128
        nodeTaints: []
      }
    ]

    networkProfile: {
      networkPlugin: 'azure'
      loadBalancerSku: 'standard'
      outboundType: 'loadBalancer'
    }

    // Integrate with Log Analytics for monitoring
    addonProfiles: {
      omsagent: {
        enabled: true
        config: { logAnalyticsWorkspaceResourceID: law.id }
      }
    }

    // Managed API server — simplest approach
    apiServerAccessProfile: { enablePrivateCluster: false }
  }
}

// ── Azure SQL Server + Database ──────────────────────────────
resource sql 'Microsoft.Sql/servers@2023-05-01-preview' = {
  name: sqlServer
  location: location
  properties: {
    administratorLogin: sqlAdminLogin
    administratorLoginPassword: sqlAdminPassword
    version: '12.0'
    minimalTlsVersion: '1.2'
  }
}

resource sqlFwAzure 'Microsoft.Sql/servers/firewallRules@2023-05-01-preview' = {
  parent: sql
  name: 'AllowAzureServices'
  properties: { startIpAddress: '0.0.0.0', endIpAddress: '0.0.0.0' }
}

resource sqlDatabase 'Microsoft.Sql/servers/databases@2023-05-01-preview' = {
  parent: sql
  name: sqlDb
  location: location
  sku: {
    name: environment == 'prod' ? 'S1' : 'Basic'
    tier: environment == 'prod' ? 'Standard' : 'Basic'
    capacity: environment == 'prod' ? 20 : 5
  }
}

// ── Key Vault ────────────────────────────────────────────────
resource kv 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: kvName
  location: location
  properties: {
    sku: { family: 'A', name: 'standard' }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
    softDeleteRetentionInDays: 7
  }
}

// Store secrets
resource kvSqlUrl  'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'AzureSqlUrl'
  properties: {
    value: 'jdbc:sqlserver://${sql.properties.fullyQualifiedDomainName}:1433;database=${sqlDb};encrypt=true;trustServerCertificate=false'
  }
}

resource kvSqlUser 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'AzureSqlUsername'
  properties: { value: sqlAdminLogin }
}

resource kvSqlPass 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'AzureSqlPassword'
  properties: { value: sqlAdminPassword }
}

resource kvAppi 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'AppInsightsConnectionString'
  properties: { value: appi.properties.ConnectionString }
}

// ── RBAC Assignments ─────────────────────────────────────────
var acrPullRoleId  = '7f951dda-4ed3-4680-a7ca-43fe172d538d'
var kvSecretUserId = '4633458b-17de-408a-b874-0445c86b69e6'

// AKS can pull images from ACR
resource acrPull 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(acr.id, aks.id, acrPullRoleId)
  scope: acr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', acrPullRoleId)
    principalId: aks.properties.identityProfile.kubeletidentity.objectId
    principalType: 'ServicePrincipal'
  }
}

// Managed Identity can read KV secrets (for workload identity)
resource kvRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(kv.id, managedIdentity.id, kvSecretUserId)
  scope: kv
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', kvSecretUserId)
    principalId: managedIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// ── Outputs ──────────────────────────────────────────────────
output aksName        string = aks.name
output acrLoginServer string = acr.properties.loginServer
output acrName        string = acr.name
output keyVaultName   string = kv.name
output sqlFqdn        string = sql.properties.fullyQualifiedDomainName
output appiConnString string = appi.properties.ConnectionString
output managedIdentityClientId string = managedIdentity.properties.clientId
output oidcIssuerUrl  string = aks.properties.oidcIssuerProfile.issuerURL
