#!/bin/bash
# ============================================================
# deploy-aks.sh — Full AKS + ACR + Azure SQL + Key Vault
# Usage: bash deploy-aks.sh [dev|staging|prod]
# ============================================================
set -euo pipefail

ENV=${1:-dev}
LOCATION="eastus"
PREFIX="emp"
RG="rg-${PREFIX}-aks-${ENV}"
SUFFIX=$(openssl rand -hex 3)

# Resource names
AKS_NAME="aks-${PREFIX}-${ENV}"
ACR_NAME="${PREFIX}acr${ENV}${SUFFIX}"
SQL_SERVER="${PREFIX}-sql-${ENV}-${SUFFIX}"
SQL_DB="${PREFIX}-db-${ENV}"
SQL_ADMIN="sqladmin"
KV_NAME="kv-${PREFIX}-${ENV}-${SUFFIX}"
APPI_NAME="appi-${PREFIX}-${ENV}"
LAW_NAME="law-${PREFIX}-${ENV}"
MI_NAME="mi-${PREFIX}-${ENV}"

read -sp "SQL Admin Password: " SQL_PASS; echo ""

# Node config by environment
if [ "$ENV" = "prod" ]; then
  NODE_COUNT=3; NODE_SIZE="Standard_D4s_v3"; SQL_EDITION="Standard"; SQL_CAP=20; ACR_SKU="Premium"
else
  NODE_COUNT=1; NODE_SIZE="Standard_D2s_v3"; SQL_EDITION="Basic";    SQL_CAP=5;  ACR_SKU="Basic"
fi

echo "╔══════════════════════════════════════════════╗"
echo "║  AKS Full-Stack Deployment                   ║"
echo "║  Env: $ENV | Location: $LOCATION             ║"
echo "╚══════════════════════════════════════════════╝"

# ── 1. Login & Resource Group ─────────────────────────────
echo "[1/12] Resource Group"
az account show --output none 2>/dev/null || az login
az group create --name $RG --location $LOCATION \
  --tags Environment=$ENV ManagedBy=CLI Project=EmployeeManagement \
  --output none
echo "  ✅ $RG"

# ── 2. Log Analytics + App Insights ──────────────────────
echo "[2/12] Monitoring"
az monitor log-analytics workspace create \
  --resource-group $RG --workspace-name $LAW_NAME --output none
LAW_ID=$(az monitor log-analytics workspace show -g $RG -n $LAW_NAME --query id -o tsv)
az monitor app-insights component create \
  --app $APPI_NAME -g $RG -l $LOCATION --workspace $LAW_ID --output none
APPI_CONN=$(az monitor app-insights component show --app $APPI_NAME -g $RG --query connectionString -o tsv)
echo "  ✅ App Insights: $APPI_NAME"

# ── 3. Azure Container Registry ───────────────────────────
echo "[3/12] Azure Container Registry: $ACR_NAME"
az acr create --name $ACR_NAME --resource-group $RG \
  --location $LOCATION --sku $ACR_SKU --admin-enabled false --output none
ACR_SERVER=$(az acr show --name $ACR_NAME --query loginServer -o tsv)
echo "  ✅ ACR: $ACR_SERVER"

# ── 4. AKS Cluster ────────────────────────────────────────
echo "[4/12] AKS Cluster: $AKS_NAME (this takes 5-10 minutes...)"
az aks create \
  --resource-group $RG \
  --name $AKS_NAME \
  --location $LOCATION \
  --node-count $NODE_COUNT \
  --node-vm-size $NODE_SIZE \
  --enable-cluster-autoscaler \
  --min-count 1 --max-count $( [ "$ENV" = "prod" ] && echo "10" || echo "3" ) \
  --enable-oidc-issuer \
  --enable-workload-identity \
  --network-plugin azure \
  --generate-ssh-keys \
  --attach-acr $ACR_NAME \
  --workspace-resource-id $LAW_ID \
  --enable-addons monitoring \
  --output none
echo "  ✅ AKS cluster ready"

# Get cluster credentials
az aks get-credentials --resource-group $RG --name $AKS_NAME --overwrite-existing
echo "  ✅ kubectl configured"

# Get OIDC issuer URL (needed for workload identity federation)
OIDC_URL=$(az aks show -g $RG -n $AKS_NAME --query "oidcIssuerProfile.issuerUrl" -o tsv)

# ── 5. User-Assigned Managed Identity ─────────────────────
echo "[5/12] Managed Identity: $MI_NAME"
az identity create --name $MI_NAME --resource-group $RG --location $LOCATION --output none
MI_CLIENT_ID=$(az identity show -g $RG -n $MI_NAME --query clientId -o tsv)
MI_PRINCIPAL_ID=$(az identity show -g $RG -n $MI_NAME --query principalId -o tsv)
MI_RESOURCE_ID=$(az identity show -g $RG -n $MI_NAME --query id -o tsv)
echo "  ✅ MI Client ID: $MI_CLIENT_ID"

# ── 6. Azure SQL ──────────────────────────────────────────
echo "[6/12] Azure SQL: $SQL_SERVER"
az sql server create -n $SQL_SERVER -g $RG -l $LOCATION \
  --admin-user $SQL_ADMIN --admin-password "$SQL_PASS" --output none
az sql server firewall-rule create -g $RG -s $SQL_SERVER \
  --name AllowAzureServices --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0 --output none
az sql db create -g $RG -s $SQL_SERVER -n $SQL_DB \
  --edition $SQL_EDITION --capacity $SQL_CAP --output none
SQL_FQDN=$(az sql server show -n $SQL_SERVER -g $RG --query fullyQualifiedDomainName -o tsv)
SQL_URL="jdbc:sqlserver://${SQL_FQDN}:1433;database=${SQL_DB};encrypt=true;trustServerCertificate=false;loginTimeout=30"
echo "  ✅ SQL: $SQL_FQDN"

# ── 7. Key Vault + Secrets ────────────────────────────────
echo "[7/12] Key Vault: $KV_NAME"
az keyvault create -n $KV_NAME -g $RG -l $LOCATION \
  --enable-rbac-authorization true --soft-delete-retention-days 7 --output none
KV_ID=$(az keyvault show -n $KV_NAME -g $RG --query id -o tsv)

# Grant yourself admin access
CURRENT_USER=$(az account show --query user.name -o tsv)
az role assignment create --assignee $CURRENT_USER --role "Key Vault Administrator" --scope $KV_ID --output none

# Store all secrets
az keyvault secret set --vault-name $KV_NAME --name AzureSqlUrl              --value "$SQL_URL"    --output none
az keyvault secret set --vault-name $KV_NAME --name AzureSqlUsername          --value "$SQL_ADMIN"  --output none
az keyvault secret set --vault-name $KV_NAME --name AzureSqlPassword          --value "$SQL_PASS"   --output none
az keyvault secret set --vault-name $KV_NAME --name AppInsightsConnectionString --value "$APPI_CONN" --output none

# Grant Managed Identity read access to Key Vault
az role assignment create \
  --assignee-object-id $MI_PRINCIPAL_ID \
  --assignee-principal-type ServicePrincipal \
  --role "Key Vault Secrets User" --scope $KV_ID --output none
echo "  ✅ Key Vault with secrets"

# ── 8. Federated Identity (Workload Identity) ──────────────
echo "[8/12] Workload Identity Federation"
az identity federated-credential create \
  --name "aks-backend-fedcred" \
  --identity-name $MI_NAME \
  --resource-group $RG \
  --issuer "$OIDC_URL" \
  --subject "system:serviceaccount:employee-app:backend-sa" \
  --audiences "api://AzureADTokenExchange" \
  --output none
echo "  ✅ Federated credential created"

# ── 9. Install Ingress Controller ─────────────────────────
echo "[9/12] Installing NGINX Ingress Controller"
kubectl create namespace ingress-nginx --dry-run=client -o yaml | kubectl apply -f -
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx --force-update
helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --set controller.replicaCount=2 \
  --set controller.service.annotations."service\.beta\.kubernetes\.io/azure-load-balancer-health-probe-request-path"=/healthz \
  --wait --timeout 5m
echo "  ✅ Ingress controller installed"

# ── 10. Install cert-manager ──────────────────────────────
echo "[10/12] Installing cert-manager (TLS)"
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.14.4/cert-manager.yaml
kubectl wait --for=condition=available deployment -l app.kubernetes.io/instance=cert-manager \
  -n cert-manager --timeout=120s
echo "  ✅ cert-manager installed"

# ── 11. Create K8s Namespace + Secret ─────────────────────
echo "[11/12] Kubernetes Namespace + Secrets"
kubectl create namespace employee-app --dry-run=client -o yaml | kubectl apply -f -

# Create Kubernetes secret from Key Vault values
kubectl create secret generic emp-secrets \
  --namespace employee-app \
  --from-literal=AZURE_SQL_URL="$SQL_URL" \
  --from-literal=AZURE_SQL_USERNAME="$SQL_ADMIN" \
  --from-literal=AZURE_SQL_PASSWORD="$SQL_PASS" \
  --from-literal=APPLICATIONINSIGHTS_CONNECTION_STRING="$APPI_CONN" \
  --dry-run=client -o yaml | kubectl apply -f -
echo "  ✅ Namespace + secrets created"

# ── 12. Summary ───────────────────────────────────────────
PUBLIC_IP=$(kubectl get svc ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "Pending...")

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║              AKS DEPLOYMENT COMPLETE ✅                  ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║ Resource Group : $RG"
echo "║ AKS Cluster    : $AKS_NAME"
echo "║ ACR             : $ACR_SERVER"
echo "║ SQL Server      : $SQL_FQDN"
echo "║ Key Vault       : $KV_NAME"
echo "║ Ingress IP      : $PUBLIC_IP"
echo "║ MI Client ID    : $MI_CLIENT_ID"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║ NEXT STEPS:"
echo "║ 1. Update pipelines with ACR name: $ACR_NAME"
echo "║ 2. Update k8s/base/ REGISTRY_PLACEHOLDER with: $ACR_SERVER"
echo "║ 3. Update serviceaccount.yaml with MI client ID: $MI_CLIENT_ID"
echo "║ 4. Run the CI/CD pipelines to build & push images"
echo "║ 5. Run: kubectl apply -k k8s/overlays/dev"
echo "╚══════════════════════════════════════════════════════════╝"

# Save outputs to file for pipeline use
cat > aks-outputs.env << EOF
ACR_SERVER=$ACR_SERVER
ACR_NAME=$ACR_NAME
AKS_NAME=$AKS_NAME
RESOURCE_GROUP=$RG
KV_NAME=$KV_NAME
MI_CLIENT_ID=$MI_CLIENT_ID
SQL_FQDN=$SQL_FQDN
EOF
echo "  📄 Outputs saved to: aks-outputs.env"
